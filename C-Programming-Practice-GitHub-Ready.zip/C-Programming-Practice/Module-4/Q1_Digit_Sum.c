#include <stdio.h>
int main(void) {
    long long n, sum = 0;
    scanf("%lld", &n);
    if (n < 0) n = -n;
    while (n > 0) { sum += n % 10; n /= 10; }
    printf("%lld\n", sum);
    return 0;
}
