#include <stdio.h>
int main(void) {
    int n; scanf("%d", &n);
    for (int i=1;i<=n;i++) {
        for (int j=1;j<=i;j++) putchar((j==1||j==i||i==n)?'*':' ');
        putchar('\n');
    }
    return 0;
}
